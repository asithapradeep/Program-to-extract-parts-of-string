/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{
    char str[]="Working with strings is fun";
    //char *ptr=str;
    int pos,num,count=0;
    scanf("%d %d",&pos,&num);
    for(int i=0;str[i]!='\0';i++){
        if(i==(pos-1)){
            if(num!=0){
            for(int j=pos-1;count!=num;j++){
            printf("%c",str[j]);
            count++;    
            }
            }
            else{
            for(int k=pos-1;str[k]!='\0';k++)
            printf("%c",str[k]);
            }
            }
    }
    

    return 0;
}
